package J240508_package1;

public class B {
	A a;//A 클래스  -a 레퍼런스 변수 선언 
}
