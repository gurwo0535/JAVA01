package J240508_package1;

//public class A { // 재한 없음 
	 public class A { // public이 없을 경우 default 접근 지정자 (같은 패키지 접근가능 )
//	private class A { //오류 (자기 클레스에서 만 접근가능 )
//		public class B {	A a;}  이게 B클래스에서 A클래스를사용할수 없음 -- private class A 경우 

}
